﻿Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel.DataAnnotations.Schema

Public Class Cliente
    <Key>
    <DatabaseGenerated(DatabaseGeneratedOption.Identity)>
    Public Property Id As Integer

    <Required>
    <MaxLength(100)>
    Public Property Nombre As String

    <Required>
    <MaxLength(100)>
    Public Property Apellido As String

    <Required>
    <MaxLength(150)>
    Public Property Email As String

    <MaxLength(30)>
    Public Property Telefono As String
End Class