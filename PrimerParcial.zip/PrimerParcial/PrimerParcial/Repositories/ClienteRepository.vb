﻿Imports Microsoft.EntityFrameworkCore

Public Class ClienteRepository
    Implements IClienteRepository

    Private ReadOnly _context As EmpresaDbContext

    Public Sub New(context As EmpresaDbContext)
        _context = context
    End Sub

    Public Async Function ObtenerTodosAsync() As Task(Of IEnumerable(Of Cliente)) Implements IClienteRepository.ObtenerTodosAsync
        Return Await _context.Clientes.ToListAsync()
    End Function

    Public Async Function ObtenerPorIdAsync(id As Integer) As Task(Of Cliente) Implements IClienteRepository.ObtenerPorIdAsync
        Return Await _context.Clientes.FindAsync(id)
    End Function

    Public Async Function RegistrarAsync(cliente As Cliente) As Task Implements IClienteRepository.RegistrarAsync
        _context.Clientes.Add(cliente)
        Await _context.SaveChangesAsync()
    End Function

    Public Async Function ModificarAsync(cliente As Cliente) As Task Implements IClienteRepository.ModificarAsync
        _context.Entry(cliente).State = EntityState.Modified
        Await _context.SaveChangesAsync()
    End Function

    Public Async Function EliminarAsync(id As Integer) As Task Implements IClienteRepository.EliminarAsync
        Dim cliente = Await _context.Clientes.FindAsync(id)
        If cliente IsNot Nothing Then
            _context.Clientes.Remove(cliente)
            Await _context.SaveChangesAsync()
        End If
    End Function
End Class