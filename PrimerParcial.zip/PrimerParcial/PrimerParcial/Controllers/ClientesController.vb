﻿Imports System.Runtime.InteropServices
Imports Microsoft.AspNetCore.Mvc

<Route("api/[controller]")>
<ApiController>
Public Class ClientesController
    Inherits ControllerBase

    Private ReadOnly _service As IClienteService

    Public Sub New(service As IClienteService)
        _service = service
    End Sub

    <HttpGet>
    Public Async Function GetClientes() As Task(Of IActionResult)
        Dim clientes = Await _service.ObtenerTodosAsync()
        Return Ok(clientes)
    End Function

    <HttpGet("{id}")>
    Public Async Function GetCliente(id As Integer) As Task(Of IActionResult)
        Dim cliente = Await _service.ObtenerPorIdAsync(id)
        If cliente Is Nothing Then Return NotFound()
        Return Ok(cliente)
    End Function

    <HttpPost>
    Public Async Function PostCliente(<FromBody> cliente As Cliente) As Task(Of IActionResult)
        Await _service.RegistrarAsync(cliente)
        Return CreatedAtAction(NameOf(GetCliente), New With {.id = cliente.Id}, cliente)
    End Function

    <HttpPut("{id}")>
    Public Async Function PutCliente(id As Integer, <FromBody> cliente As Cliente) As Task(Of IActionResult)
        If id <> cliente.Id Then Return BadRequest()
        Await _service.ModificarAsync(cliente)
        Return NoContent()
    End Function

    <HttpDelete("{id}")>
    Public Async Function DeleteCliente(id As Integer) As Task(Of IActionResult)
        Await _service.EliminarAsync(id)
        Return NoContent()
    End Function
End Class
