﻿Imports Microsoft.AspNetCore.Builder
Imports Microsoft.Extensions.DependencyInjection
Imports Microsoft.Extensions.Hosting
Imports Microsoft.EntityFrameworkCore
Imports Microsoft.Extensions.Configuration

Module Program
    Sub Main(args As String())
        Dim builder = WebApplication.CreateBuilder(args)

        builder.Services.AddControllers()

        builder.Services.AddDbContext(Of EmpresaDbContext)(Function(options) _
            options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")))

        builder.Services.AddScoped(Of IClienteRepository, ClienteRepository)()
        builder.Services.AddScoped(Of IClienteService, ClienteService)()

        Dim app = builder.Build()

        app.UseAuthorization()
        app.MapControllers()

        app.Run()
    End Sub
End Module
