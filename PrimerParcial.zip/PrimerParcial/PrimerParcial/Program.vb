﻿Imports Microsoft.AspNetCore.Builder
Imports Microsoft.Extensions.DependencyInjection
Imports Microsoft.Extensions.Hosting
Imports Microsoft.EntityFrameworkCore
Imports Microsoft.Extensions.Configuration

Module Program
    Sub Main(args As String())
        Dim builder = WebApplication.CreateBuilder(args)

        ' 1. Agregar soporte para los Controladores
        builder.Services.AddControllers()

        ' =========================================================
        ' PASO 8: INYECCIÓN DE DEPENDENCIAS
        ' =========================================================
        ' A. Registrar el DbContext (Conexión a SQL Server)
        builder.Services.AddDbContext(Of EmpresaDbContext)(Function(options) _
            options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")))

        ' B. Registrar Repository y Service
        builder.Services.AddScoped(Of IClienteRepository, ClienteRepository)()
        builder.Services.AddScoped(Of IClienteService, ClienteService)()
        ' =========================================================

        Dim app = builder.Build()

        ' 2. Configurar el enrutamiento HTTP
        app.UseAuthorization()
        app.MapControllers()

        ' 3. Arrancar la API
        app.Run()
    End Sub
End Module
