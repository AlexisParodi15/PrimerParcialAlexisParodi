﻿Public Interface IClienteService
    Function ObtenerTodosAsync() As Task(Of IEnumerable(Of Cliente))
    Function ObtenerPorIdAsync(id As Integer) As Task(Of Cliente)
    Function RegistrarAsync(cliente As Cliente) As Task
    Function ModificarAsync(cliente As Cliente) As Task
    Function EliminarAsync(id As Integer) As Task
End Interface
