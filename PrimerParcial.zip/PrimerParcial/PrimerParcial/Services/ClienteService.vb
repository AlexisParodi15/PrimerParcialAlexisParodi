﻿Public Class ClienteService
    Implements IClienteService

    Private ReadOnly _repository As IClienteRepository

    Public Sub New(repository As IClienteRepository)
        _repository = repository
    End Sub

    Public Async Function ObtenerTodosAsync() As Task(Of IEnumerable(Of Cliente)) Implements IClienteService.ObtenerTodosAsync
        Return Await _repository.ObtenerTodosAsync()
    End Function

    Public Async Function ObtenerPorIdAsync(id As Integer) As Task(Of Cliente) Implements IClienteService.ObtenerPorIdAsync
        Return Await _repository.ObtenerPorIdAsync(id)
    End Function

    Public Async Function RegistrarAsync(cliente As Cliente) As Task Implements IClienteService.RegistrarAsync
        Await _repository.RegistrarAsync(cliente)
    End Function

    Public Async Function ModificarAsync(cliente As Cliente) As Task Implements IClienteService.ModificarAsync
        Await _repository.ModificarAsync(cliente)
    End Function

    Public Async Function EliminarAsync(id As Integer) As Task Implements IClienteService.EliminarAsync
        Await _repository.EliminarAsync(id)
    End Function
End Class
