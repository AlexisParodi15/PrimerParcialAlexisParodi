﻿Imports Microsoft.EntityFrameworkCore

Public Class EmpresaDbContext
    Inherits DbContext

    Public Sub New(options As DbContextOptions(Of EmpresaDbContext))
        MyBase.New(options)
    End Sub

    Public Property Clientes As DbSet(Of Cliente)
End Class